from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo

print(logo)

all_bidders = {}

def check_highest_bidde(bidders):
  highest = 0
  for key in bidders:
    bid = bidders[key]
    if bid > highest:
      highest = bid
      winner = key
  print(f"The winner of today's bid is {winner}")
      
continue_bid = True
while continue_bid:
  name = input("Enter your name\n")
  price = int(input("Enter price\n$"))
  all_bidders[name] = price
  
  request = input("Is there any other bidder 'yes' or 'no': ")
  clear()
  
  if request == 'no':
    check_highest_bidde(all_bidders)
    print(all_bidders)
    continue_bid = False